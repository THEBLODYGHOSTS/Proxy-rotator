<#
.SYNOPSIS
    proxy-rotator :: installer for Windows

.DESCRIPTION
    Installs proxy_rotator.py into %LOCALAPPDATA%\proxy-rotator, creates a
    "proxy-rotator" launcher and adds it to the user PATH.
    Optionally installs PySocks (SOCKS4/SOCKS5 support) in a private venv.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\install.ps1

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\install.ps1 -WithSocks

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\install.ps1 -Uninstall
#>

param(
    [switch]$WithSocks,
    [switch]$Uninstall,
    [string]$Prefix = (Join-Path $env:LOCALAPPDATA "proxy-rotator")
)

$ErrorActionPreference = "Stop"
$App    = "proxy-rotator"
$Repo   = "https://raw.githubusercontent.com/THEBLODYGHOSTS/proxy-rotator/main/proxy_rotator.py"
$BinDir = Join-Path $Prefix "bin"
$Target = Join-Path $Prefix "proxy_rotator.py"
$Venv   = Join-Path $Prefix "venv"

function Write-Ok   ($m) { Write-Host "[+] $m" -ForegroundColor Green }
function Write-Info ($m) { Write-Host "[~] $m" -ForegroundColor Magenta }
function Write-Warn ($m) { Write-Host "[!] $m" -ForegroundColor Yellow }
function Fail       ($m) { Write-Host "[x] $m" -ForegroundColor Red; exit 1 }

function Get-UserPath {
    $p = [Environment]::GetEnvironmentVariable("Path", "User")
    if ([string]::IsNullOrWhiteSpace($p)) { return @() }
    return @($p -split ";" | Where-Object { $_ -ne "" })
}

function Set-UserPath ([string[]]$Parts) {
    [Environment]::SetEnvironmentVariable("Path", ($Parts -join ";"), "User")
}

# ---------------------------------------------------------------------------
# Uninstall
# ---------------------------------------------------------------------------
if ($Uninstall) {
    Write-Info "removing $App from $Prefix"
    if (Test-Path $Prefix) { Remove-Item -Recurse -Force $Prefix }
    $parts = Get-UserPath | Where-Object { $_ -ne $BinDir }
    Set-UserPath $parts
    Write-Ok "uninstalled (alive.txt and other state files were left untouched)"
    exit 0
}

# ---------------------------------------------------------------------------
# Python 3.8+
# ---------------------------------------------------------------------------
$candidates = @(
    @{ Exe = "py";      Args = @("-3") },
    @{ Exe = "python";  Args = @() },
    @{ Exe = "python3"; Args = @() }
)

$PythonPath = $null
foreach ($c in $candidates) {
    if (-not (Get-Command $c.Exe -ErrorAction SilentlyContinue)) { continue }
    try {
        $probeArgs = $c.Args + @("-c", "import sys; print(sys.executable)")
        $real = & $c.Exe @probeArgs 2>$null
        if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($real)) { continue }
        $real = ([string]$real).Trim()
        & $real -c "import sys; sys.exit(0 if sys.version_info >= (3, 8) else 1)" 2>$null
        if ($LASTEXITCODE -eq 0) { $PythonPath = $real; break }
    } catch { continue }
}

if (-not $PythonPath) {
    Fail "Python 3.8+ was not found. Install it from https://www.python.org/downloads/ and tick 'Add python.exe to PATH'."
}

$PyVer = (& $PythonPath -c "import platform; print(platform.python_version())").Trim()
Write-Ok "python $PyVer ($PythonPath)"

# ---------------------------------------------------------------------------
# Get the program (local file when run from the repo, otherwise download)
# ---------------------------------------------------------------------------
New-Item -ItemType Directory -Force -Path $Prefix | Out-Null
New-Item -ItemType Directory -Force -Path $BinDir | Out-Null

$local = Join-Path $PSScriptRoot "proxy_rotator.py"
if (Test-Path $local) {
    Copy-Item -Force $local $Target
    Write-Info "copied local proxy_rotator.py"
} else {
    Write-Info "downloading $App from GitHub ..."
    try {
        Invoke-WebRequest -UseBasicParsing -Uri $Repo -OutFile $Target
    } catch {
        Fail "download failed: $Repo"
    }
}
Write-Ok "installed program: $Target"

# ---------------------------------------------------------------------------
# Optional: PySocks inside a private venv
# ---------------------------------------------------------------------------
$Runner = $PythonPath
$SocksState = "not installed (HTTP/HTTPS only)"
if ($WithSocks) {
    Write-Info "creating a private venv for PySocks ..."
    try {
        & $PythonPath -m venv $Venv
        if ($LASTEXITCODE -ne 0) { throw "venv creation failed" }
        $venvPy = Join-Path $Venv "Scripts\python.exe"
        & $venvPy -m pip install --quiet --disable-pip-version-check PySocks
        if ($LASTEXITCODE -ne 0) { throw "pip install failed" }
        $Runner = $venvPy
        $SocksState = "PySocks in $Venv"
        Write-Ok "SOCKS4/SOCKS5 support enabled"
    } catch {
        Write-Warn "could not install PySocks (offline?) - continuing with HTTP/HTTPS"
        $Runner = $PythonPath
    }
}

# ---------------------------------------------------------------------------
# Launcher
# ---------------------------------------------------------------------------
$launcher = Join-Path $BinDir "$App.cmd"
$content = "@echo off`r`n`"$Runner`" `"$Target`" %*`r`n"
Set-Content -Path $launcher -Value $content -Encoding ASCII
Write-Ok "launcher: $launcher"

# ---------------------------------------------------------------------------
# PATH (user scope)
# ---------------------------------------------------------------------------
$parts = Get-UserPath
if ($parts -notcontains $BinDir) {
    Set-UserPath (@($BinDir) + $parts)
    Write-Info "added $BinDir to your user PATH (open a new terminal)"
}

# ---------------------------------------------------------------------------
# Done
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "  proxy-rotator is ready." -ForegroundColor Green
Write-Host ""
Write-Host "  binary   $launcher"
Write-Host "  python   $PythonPath ($PyVer)"
Write-Host "  socks    $SocksState"
Write-Host ""
Write-Host "  try      proxy-rotator --once"
Write-Host "  run      proxy-rotator"
Write-Host "  help     proxy-rotator --help"
Write-Host "  remove   powershell -ExecutionPolicy Bypass -File .\install.ps1 -Uninstall"
Write-Host ""
Write-Host "  Only use proxies you are allowed to use. Public proxies can read" -ForegroundColor DarkGray
Write-Host "  your unencrypted traffic - never send credentials through them." -ForegroundColor DarkGray
Write-Host ""
