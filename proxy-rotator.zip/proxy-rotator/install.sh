#!/usr/bin/env bash
# ---------------------------------------------------------------------------
#  proxy-rotator :: installer (Linux / macOS)
#  https://github.com/THEBLODYGHOSTS/proxy-rotator
#
#  Usage:
#     ./install.sh                 install to ~/.local  (no sudo needed)
#     ./install.sh --with-socks    also install PySocks in a private venv
#     ./install.sh --prefix /usr/local
#     ./install.sh --uninstall
#
#  Env:
#     PREFIX   install prefix (default: ~/.local)
# ---------------------------------------------------------------------------
set -euo pipefail

APP="proxy-rotator"
REPO_RAW="https://raw.githubusercontent.com/THEBLODYGHOSTS/proxy-rotator/main/proxy_rotator.py"
PREFIX="${PREFIX:-$HOME/.local}"
BIN="$PREFIX/bin"
SHARE="$PREFIX/share/$APP"
TARGET="$SHARE/proxy_rotator.py"
WITH_SOCKS=0
DO_UNINSTALL=0
NO_PATH=0

if [ -t 1 ]; then
    G=$'\033[0;32m'; P=$'\033[0;35m'; R=$'\033[0;31m'; D=$'\033[2m'; N=$'\033[0m'
else
    G=""; P=""; R=""; D=""; N=""
fi

say()  { printf '%s\n' "$*"; }
ok()   { printf '%s[+]%s %s\n' "$G" "$N" "$*"; }
info() { printf '%s[~]%s %s\n' "$P" "$N" "$*"; }
die()  { printf '%s[x]%s %s\n' "$R" "$N" "$*" >&2; exit 1; }

usage() {
    cat <<EOF
${APP} installer

  ./install.sh                  install into ${PREFIX}
  ./install.sh --with-socks     install PySocks too (SOCKS4/5 support)
  ./install.sh --prefix <dir>   custom prefix (bin/ and share/ live there)
  ./install.sh --no-path        do not modify shell rc files
  ./install.sh --uninstall      remove the installation

After install:  ${BIN}/${APP} --once
EOF
}

while [ $# -gt 0 ]; do
    case "$1" in
        --with-socks) WITH_SOCKS=1 ;;
        --prefix)     [ $# -ge 2 ] || die "--prefix needs a directory"; PREFIX="$2"; shift ;;
        --uninstall)  DO_UNINSTALL=1 ;;
        --no-path)    NO_PATH=1 ;;
        -h|--help)    usage; exit 0 ;;
        *)            die "unknown option: $1 (try --help)" ;;
    esac
    shift
done

BIN="$PREFIX/bin"
SHARE="$PREFIX/share/$APP"
TARGET="$SHARE/proxy_rotator.py"

# --------------------------------------------------------------------------
# Remove the PATH block that this installer may have added
# --------------------------------------------------------------------------
remove_path_block() {
    local rc="$1"
    [ -f "$rc" ] || return 0
    grep -q "# $APP-path" "$rc" || return 0
    awk -v marker="# $APP-path" '
        $0 == marker { skip = 2; next }
        skip > 0 { skip--; next }
        { print }
    ' "$rc" > "$rc.tmp.$$" && mv "$rc.tmp.$$" "$rc"
}

# --------------------------------------------------------------------------
# Uninstall
# --------------------------------------------------------------------------
if [ "$DO_UNINSTALL" -eq 1 ]; then
    info "removing $APP from $PREFIX"
    rm -f "$BIN/$APP"
    rm -rf "$SHARE"
    for rc in "$HOME/.bashrc" "$HOME/.zshrc" "$HOME/.profile"; do
        remove_path_block "$rc"
    done
    ok "uninstalled (state files such as alive.txt were left untouched)"
    exit 0
fi

# --------------------------------------------------------------------------
# Python 3.8+
# --------------------------------------------------------------------------
PYTHON=""
for candidate in python3 python; do
    command -v "$candidate" >/dev/null 2>&1 || continue
    if "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 8) else 1)' 2>/dev/null; then
        PYTHON="$candidate"
        break
    fi
done
[ -n "$PYTHON" ] || die "Python 3.8+ was not found. Install it first (apt install python3 / brew install python)."

PYVER="$("$PYTHON" -c 'import platform; print(platform.python_version())')"
ok "python $PYVER ($(command -v "$PYTHON"))"

# --------------------------------------------------------------------------
# Get the program (local file when run from the repo, otherwise download)
# --------------------------------------------------------------------------
mkdir -p "$SHARE" "$BIN"

SELF_DIR=""
if [ -n "${BASH_SOURCE[0]:-}" ] && [ -f "${BASH_SOURCE[0]}" ]; then
    SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
fi

if [ -n "$SELF_DIR" ] && [ -f "$SELF_DIR/proxy_rotator.py" ]; then
    cp "$SELF_DIR/proxy_rotator.py" "$TARGET"
    info "copied local proxy_rotator.py"
else
    command -v curl >/dev/null 2>&1 || die "curl is required to download the program"
    info "downloading $APP from GitHub ..."
    curl -fsSL "$REPO_RAW" -o "$TARGET" || die "download failed: $REPO_RAW"
fi
chmod 0755 "$TARGET"
ok "installed program: $TARGET"

# --------------------------------------------------------------------------
# Optional: PySocks inside a private venv
# --------------------------------------------------------------------------
RUNNER="$PYTHON"
SOCKS_STATE="not installed (HTTP/HTTPS only)"
if [ "$WITH_SOCKS" -eq 1 ]; then
    info "creating a private venv for PySocks ..."
    if "$PYTHON" -m venv "$SHARE/venv" 2>/dev/null \
       && "$SHARE/venv/bin/pip" install --quiet --disable-pip-version-check PySocks 2>/dev/null; then
        RUNNER="$SHARE/venv/bin/python"
        SOCKS_STATE="PySocks in $SHARE/venv"
        ok "SOCKS4/SOCKS5 support enabled"
    else
        printf '%s[!]%s could not install PySocks (offline?) - continuing with HTTP/HTTPS\n' "$R" "$N"
    fi
fi

# --------------------------------------------------------------------------
# Launcher
# --------------------------------------------------------------------------
cat > "$BIN/$APP" <<EOF
#!/usr/bin/env bash
exec "$RUNNER" "$TARGET" "\$@"
EOF
chmod 0755 "$BIN/$APP"
ok "launcher: $BIN/$APP"

# --------------------------------------------------------------------------
# PATH
# --------------------------------------------------------------------------
case ":$PATH:" in
    *":$BIN:"*) IN_PATH=1 ;;
    *)          IN_PATH=0 ;;
esac

if [ "$NO_PATH" -eq 0 ] && [ "$IN_PATH" -eq 0 ]; then
    TOUCHED=0
    for rc in "$HOME/.bashrc" "$HOME/.zshrc"; do
        [ -f "$rc" ] || continue
        if ! grep -q "# $APP-path" "$rc"; then
            printf '\n# %s-path\nexport PATH="%s:$PATH"\n' "$APP" "$BIN" >> "$rc"
            TOUCHED=1
        fi
    done
    if [ "$TOUCHED" -eq 1 ]; then
        info "added $BIN to PATH in your shell rc (open a new terminal)"
    fi
fi

# --------------------------------------------------------------------------
# Done
# --------------------------------------------------------------------------
cat <<EOF

  ${G}${APP}${N} is ready.

  ${D}binary${N}   $BIN/$APP
  ${D}python${N}   $(command -v "$PYTHON")  ($PYVER)
  ${D}socks${N}    $SOCKS_STATE

  ${D}try${N}      $APP --once
  ${D}run${N}      $APP
  ${D}help${N}     $APP --help
  ${D}remove${N}   ./install.sh --uninstall

  Only use proxies you are allowed to use. Public proxies can read
  your unencrypted traffic - never send credentials through them.

EOF
