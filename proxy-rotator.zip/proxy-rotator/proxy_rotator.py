#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
proxy-rotator
=============

A dependency-free (stdlib only) proxy scraper + checker + rotator.

What it does
------------
1. Downloads ~100 public proxy-list sources concurrently.
2. Extracts every ``ip:port`` it can find and de-duplicates them.
3. Checks them concurrently by sending a real HTTP request *through* the proxy
   (that is the only reliable "ping": a TCP/ICMP ping says nothing about whether
   the proxy actually forwards traffic).  Latency and the egress IP are recorded;
   proxies that do not answer, or that leak your real IP, are dropped.
4. Keeps the working proxies sorted by latency and rotates the system proxy
   every N seconds (default 3).
5. When only a few unused proxies are left, it re-scrapes and re-checks in the
   background, then keeps rotating with the fresh ones.

System proxy backends: GNOME/Linux (gsettings), Windows (WinINET registry),
macOS (networksetup), Android via adb, or environment variables only.

Only use this with proxies and networks you are allowed to use.  Free public
proxies can read/modify your unencrypted traffic - never send credentials
through them.

Run ``python3 proxy_rotator.py --help`` for all options.
"""

from __future__ import annotations

import argparse
import atexit
import gzip
import os
import random
import re
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Iterable, Optional

try:  # optional, only needed for SOCKS proxies
    import socks  # type: ignore  # PySocks
except Exception:  # pragma: no cover
    socks = None

__version__ = "1.0.0"

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)

IPPORT_RE = re.compile(r"(?<![\d.])((?:\d{1,3}\.){3}\d{1,3}):(\d{1,5})(?![\d.])")
IPV4_RE = re.compile(r"(?<![\d.])(?:\d{1,3}\.){3}\d{1,3}(?![\d.])")

MAX_SOURCE_BYTES = 4 * 1024 * 1024
MAX_RESPONSE_BYTES = 32 * 1024

HTTP_KINDS = ("http", "https")
SOCKS_KINDS = ("socks4", "socks5")

DEFAULT_CHECK_HOSTS = [
    ("checkip.amazonaws.com", 80, "/"),
    ("icanhazip.com", 80, "/"),
    ("api.ipify.org", 80, "/"),
    ("ifconfig.me", 80, "/ip"),
    ("ipinfo.io", 80, "/ip"),
]


# ---------------------------------------------------------------------------
# Default sources (100+).  (url, protocol)
# ---------------------------------------------------------------------------

def _gh(repo: str, branch: str, files: Iterable[tuple[str, str]]) -> list[tuple[str, str]]:
    base = f"https://raw.githubusercontent.com/{repo}/{branch}/"
    return [(base + path, kind) for path, kind in files]


def _proxyscrape(protocol: str, **extra: str) -> tuple[str, str]:
    params = {
        "request": "displayproxies",
        "protocol": protocol,
        "timeout": "10000",
        "country": "all",
        "ssl": "all",
        "anonymity": "all",
    }
    params.update(extra)
    kind = "https" if protocol == "https" else protocol
    return "https://api.proxyscrape.com/v2/?" + urllib.parse.urlencode(params), kind


def default_sources() -> list[tuple[str, str]]:
    src: list[tuple[str, str]] = []
    src += _gh("TheSpeedX/PROXY-List", "master", [
        ("http.txt", "http"), ("socks4.txt", "socks4"), ("socks5.txt", "socks5")])
    src += _gh("monosans/proxy-list", "main", [
        ("proxies/http.txt", "http"), ("proxies/socks4.txt", "socks4"),
        ("proxies/socks5.txt", "socks5"), ("proxies/all.txt", "http")])
    src += _gh("ShiftyTR/Proxy-List", "master", [
        ("http.txt", "http"), ("socks4.txt", "socks4"), ("socks5.txt", "socks5")])
    src += _gh("mmpx12/proxy-list", "master", [
        ("http.txt", "http"), ("https.txt", "https"),
        ("socks4.txt", "socks4"), ("socks5.txt", "socks5")])
    src += _gh("zloi-user/hideip.me", "main", [
        ("http.txt", "http"), ("https.txt", "https"),
        ("socks4.txt", "socks4"), ("socks5.txt", "socks5")])
    src += _gh("jetkai/proxy-list", "main", [
        ("online-proxies/txt/proxies-http.txt", "http"),
        ("online-proxies/txt/proxies-https.txt", "https"),
        ("online-proxies/txt/proxies-socks4.txt", "socks4"),
        ("online-proxies/txt/proxies-socks5.txt", "socks5")])
    src += _gh("proxifly/free-proxy-list", "main", [
        ("proxies/protocols/http/data.txt", "http"),
        ("proxies/protocols/https/data.txt", "https"),
        ("proxies/protocols/socks4/data.txt", "socks4"),
        ("proxies/protocols/socks5/data.txt", "socks5"),
        ("proxies/all/data.txt", "http")])
    src += _gh("vakhov/fresh-proxy-list", "master", [
        ("http.txt", "http"), ("https.txt", "https"),
        ("socks4.txt", "socks4"), ("socks5.txt", "socks5")])
    src += _gh("Anonym0usWork1221/Free-Proxies", "main", [
        ("proxy_files/http_proxies.txt", "http"),
        ("proxy_files/https_proxies.txt", "https"),
        ("proxy_files/socks4_proxies.txt", "socks4"),
        ("proxy_files/socks5_proxies.txt", "socks5")])
    src += _gh("roosterkid/openproxylist", "main", [
        ("HTTP_RAW.txt", "http"), ("HTTPS_RAW.txt", "https"),
        ("SOCKS4_RAW.txt", "socks4"), ("SOCKS5_RAW.txt", "socks5")])
    src += _gh("ALIILAPRO/Proxy", "main", [("http.txt", "http"), ("socks5.txt", "socks5")])
    src += _gh("zevtyardt/proxy-list", "main", [
        ("http.txt", "http"), ("socks4.txt", "socks4"), ("socks5.txt", "socks5")])
    src += _gh("B4RC0DE-TM/proxy-list", "main", [
        ("HTTP.txt", "http"), ("HTTPS.txt", "https"),
        ("SOCKS4.txt", "socks4"), ("SOCKS5.txt", "socks5")])
    src += _gh("MuRongPIG/Proxy-Master", "main", [("http.txt", "http"), ("socks5.txt", "socks5")])
    src += _gh("rtunazzz/Proxy-List", "main", [("http.txt", "http"), ("socks5.txt", "socks5")])
    src += _gh("sunny9577/proxy-scraper", "master", [("proxies.txt", "http")])
    src += _gh("clarketm/proxy-list", "master", [("proxy-list-raw.txt", "http")])
    src += _gh("openproxyspace/proxy-list", "main", [("proxies.txt", "http")])
    src += _gh("proxy4parsing/proxy-list", "main", [
        ("http.txt", "http"), ("https.txt", "https"),
        ("socks4.txt", "socks4"), ("socks5.txt", "socks5")])
    src += _gh("princekrvert/proxy-list", "main", [("proxies.txt", "http")])
    src += _gh("hanwayTech/free-proxy-list", "main", [
        ("http.txt", "http"), ("https.txt", "https"),
        ("socks4.txt", "socks4"), ("socks5.txt", "socks5")])
    src += _gh("HyperBeats/proxy-list", "main", [("http.txt", "http"), ("socks5.txt", "socks5")])
    src += _gh("hookzof/socks5_list", "master", [("proxy.txt", "socks5")])
    src += _gh("andigwandi/free-proxy", "main", [("proxy_list.txt", "http")])
    src += _gh("Yarmouk-Proxy/proxy-list", "main", [("http.txt", "http")])
    src += _gh("ObcbO/getproxy", "master", [("http.txt", "http"), ("socks.txt", "socks5")])
    src += _gh("wuchunfu/proxy-list", "main", [("http.txt", "http")])
    src += _gh("fate0/proxylist", "master", [("proxy.list", "http")])
    src += _gh("almroot/proxylist", "master", [("list.txt", "http")])
    src += _gh("opsxcq/proxy-list", "master", [("list.txt", "http")])
    src += _gh("Vauth/proxy", "main", [("http.txt", "http")])

    # Plain HTTP list services
    src += [
        _proxyscrape("http"),
        _proxyscrape("https"),
        _proxyscrape("socks4"),
        _proxyscrape("socks5"),
        _proxyscrape("http", ssl="yes"),
        _proxyscrape("http", ssl="no"),
        _proxyscrape("http", anonymity="elite"),
        _proxyscrape("https", anonymity="elite"),
        ("https://www.proxy-list.download/api/v1/get?type=http", "http"),
        ("https://www.proxy-list.download/api/v1/get?type=https", "https"),
        ("https://www.proxy-list.download/api/v1/get?type=socks4", "socks4"),
        ("https://www.proxy-list.download/api/v1/get?type=socks5", "socks5"),
        ("https://proxyspace.pro/http.txt", "http"),
        ("https://proxyspace.pro/https.txt", "https"),
        ("https://proxyspace.pro/socks4.txt", "socks4"),
        ("https://proxyspace.pro/socks5.txt", "socks5"),
        ("https://spys.me/proxy.txt", "http"),
        ("https://spys.me/socks.txt", "socks5"),
        ("https://api.openproxylist.xyz/http.txt", "http"),
        ("https://api.openproxylist.xyz/socks4.txt", "socks4"),
        ("https://api.openproxylist.xyz/socks5.txt", "socks5"),
        ("https://rootjazz.com/proxies/proxies.txt", "http"),
        ("https://proxylist.geonode.com/api/proxy-list?limit=500&page=1&sort_by=lastChecked&sort_type=desc", "http"),
        ("https://proxylist.geonode.com/api/proxy-list?limit=500&page=2&sort_by=lastChecked&sort_type=desc", "http"),
        ("https://proxylist.geonode.com/api/proxy-list?limit=500&page=3&sort_by=lastChecked&sort_type=desc", "http"),
        ("https://www.my-proxy.com/free-proxy-list.html", "http"),
        ("https://free-proxy-list.net/", "http"),
        ("https://www.sslproxies.org/", "https"),
        ("https://www.us-proxy.org/", "http"),
        ("https://www.socks-proxy.net/", "socks5"),
    ]
    return src


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def make_logger(quiet: bool):
    lock = threading.Lock()

    def log(message: str) -> None:
        if quiet:
            return
        stamp = time.strftime("%H:%M:%S")
        with lock:
            print(f"[{stamp}] {message}", flush=True)

    return log


# ---------------------------------------------------------------------------
# Proxy model
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Proxy:
    kind: str
    host: str
    port: int
    latency_ms: float = 0.0
    egress: str = ""

    @property
    def key(self) -> str:
        return f"{self.kind}://{self.host}:{self.port}"

    def label(self) -> str:
        return f"{self.host}:{self.port}"


def parse_ip_port(text: str, kind: str) -> list[Proxy]:
    found: list[Proxy] = []
    for match in IPPORT_RE.finditer(text):
        host, port_raw = match.group(1), match.group(2)
        if any(int(octet) > 255 for octet in host.split(".")):
            continue
        port = int(port_raw)
        if not 0 < port < 65536:
            continue
        found.append(Proxy(kind, host, port))
    return found


# ---------------------------------------------------------------------------
# Source download
# ---------------------------------------------------------------------------

_DIRECT = urllib.request.build_opener(urllib.request.ProxyHandler({}))


def fetch_direct(url: str, timeout: float) -> str:
    request = urllib.request.Request(
        url, headers={"User-Agent": UA, "Accept": "*/*"})
    with _DIRECT.open(request, timeout=timeout) as response:
        raw = response.read(MAX_SOURCE_BYTES)
        encoding = (response.headers.get("Content-Encoding") or "").lower()
    if encoding == "gzip":
        try:
            raw = gzip.decompress(raw)
        except OSError:
            pass
    return raw.decode("utf-8", "replace")


def scrape(sources: list[tuple[str, str]], *, workers: int, timeout: float,
           per_source_cap: int, log) -> list[Proxy]:
    collected: list[Proxy] = []

    def worker(item: tuple[str, str]) -> list[Proxy]:
        url, kind = item
        try:
            text = fetch_direct(url, timeout)
        except Exception as exc:  # noqa: BLE001 - any network error is fine here
            log(f"[scrape] FAIL {url} ({exc})")
            return []
        proxies = parse_ip_port(text, kind)[:per_source_cap]
        log(f"[scrape] {len(proxies):5d}  {url}")
        return proxies

    with ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        futures = {pool.submit(worker, item): item for item in sources}
        for future in as_completed(futures):
            collected.extend(future.result())

    unique: dict[str, Proxy] = {}
    for proxy in collected:
        unique.setdefault(proxy.key, proxy)
    return list(unique.values())


# ---------------------------------------------------------------------------
# HTTP-over-socket helpers (uniform for HTTP and SOCKS proxies)
# ---------------------------------------------------------------------------

def _read_until_close(sock: socket.socket, deadline: float,
                      limit: int = MAX_RESPONSE_BYTES) -> bytes:
    buffer = bytearray()
    while len(buffer) < limit:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        sock.settimeout(remaining)
        try:
            chunk = sock.recv(8192)
        except (socket.timeout, TimeoutError):
            break
        if not chunk:
            break
        buffer += chunk
    return bytes(buffer)


def _status_ok(response: bytes) -> bool:
    line = response.split(b"\r\n", 1)[0]
    parts = line.split()
    return len(parts) >= 2 and parts[1].startswith(b"2")


def _body(response: bytes) -> bytes:
    _, separator, body = response.partition(b"\r\n\r\n")
    return body if separator else b""


def _host_header(host: str, port: int) -> str:
    return host if port == 80 else f"{host}:{port}"


def _http_get_direct(host: str, port: int, path: str, timeout: float) -> bytes:
    deadline = time.monotonic() + timeout
    with socket.create_connection((host, port), timeout=timeout) as sock:
        request = (
            f"GET {path} HTTP/1.1\r\n"
            f"Host: {_host_header(host, port)}\r\n"
            f"User-Agent: {UA}\r\nAccept: */*\r\nConnection: close\r\n\r\n"
        )
        sock.sendall(request.encode())
        return _read_until_close(sock, deadline)


def check_proxy(proxy: Proxy, check: tuple[str, int, str], timeout: float,
                local_ip: str, require_egress_diff: bool) -> Optional[Proxy]:
    """Returns the proxy with latency/egress filled in, or None if unusable."""
    host, port, path = check
    deadline = time.monotonic() + timeout
    started = time.monotonic()
    sock: Optional[socket.socket] = None

    try:
        if proxy.kind in HTTP_KINDS:
            sock = socket.create_connection((proxy.host, proxy.port), timeout=timeout)
            header = _host_header(host, port)
            request = (
                f"GET http://{header}{path} HTTP/1.1\r\n"
                f"Host: {header}\r\n"
                f"User-Agent: {UA}\r\nAccept: */*\r\nConnection: close\r\n\r\n"
            )
            sock.sendall(request.encode())
            response = _read_until_close(sock, deadline)
        elif proxy.kind in SOCKS_KINDS:
            if socks is None:
                return None
            raw = socks.socksocket()
            raw.set_proxy(socks.SOCKS4 if proxy.kind == "socks4" else socks.SOCKS5,
                          proxy.host, proxy.port)
            raw.settimeout(timeout)
            raw.connect((host, port))
            sock = raw
            request = (
                f"GET {path} HTTP/1.1\r\n"
                f"Host: {_host_header(host, port)}\r\n"
                f"User-Agent: {UA}\r\nAccept: */*\r\nConnection: close\r\n\r\n"
            )
            sock.sendall(request.encode())
            response = _read_until_close(sock, deadline)
        else:
            return None
    except Exception:  # noqa: BLE001 - dead proxies raise all sorts of things
        return None
    finally:
        if sock is not None:
            try:
                sock.close()
            except Exception:
                pass

    if not _status_ok(response):
        return None

    match = IPV4_RE.search(_body(response).decode("latin-1", "replace"))
    if not match:
        return None
    egress = match.group(0)
    if require_egress_diff and local_ip and egress == local_ip:
        return None

    latency = (time.monotonic() - started) * 1000.0
    return replace(proxy, latency_ms=latency, egress=egress)


def pick_check_target(log, preferred: Optional[str], timeout: float
                      ) -> tuple[tuple[str, int, str], str]:
    candidates: list[tuple[str, int, str]] = []
    if preferred:
        parsed = urllib.parse.urlsplit(preferred)
        if parsed.scheme != "http":
            raise SystemExit("--check-url must start with http:// (HTTPS via free proxies is unreliable)")
        path = parsed.path or "/"
        if parsed.query:
            path += "?" + parsed.query
        candidates.append((parsed.hostname or "", parsed.port or 80, path))
    candidates += [c for c in DEFAULT_CHECK_HOSTS if c not in candidates]

    for host, port, path in candidates:
        try:
            response = _http_get_direct(host, port, path, timeout)
            match = IPV4_RE.search(_body(response).decode("latin-1", "replace"))
            if match and _status_ok(response):
                log(f"[check] using http://{_host_header(host, port)}{path}")
                return (host, port, path), match.group(0)
        except Exception:
            continue

    raise SystemExit("could not reach any IP-echo service - is there internet access?")


def local_public_ip() -> Optional[str]:
    for host, port, path in DEFAULT_CHECK_HOSTS:
        try:
            response = _http_get_direct(host, port, path, 4.0)
            match = IPV4_RE.search(_body(response).decode("latin-1", "replace"))
            if match:
                return match.group(0)
        except Exception:
            continue
    return None


# ---------------------------------------------------------------------------
# Pool of working proxies
# ---------------------------------------------------------------------------

class Pool:
    def __init__(self) -> None:
        self._items: list[Proxy] = []
        self._used: set[str] = set()
        self._lock = threading.Lock()

    def add(self, proxies: Iterable[Proxy]) -> int:
        added = 0
        with self._lock:
            known = {p.key for p in self._items}
            for proxy in proxies:
                if proxy.key not in known:
                    known.add(proxy.key)
                    self._items.append(proxy)
                    added += 1
            self._items.sort(key=lambda p: p.latency_ms)
        return added

    def take(self) -> Optional[Proxy]:
        with self._lock:
            for proxy in self._items:
                if proxy.key not in self._used:
                    self._used.add(proxy.key)
                    return proxy
            return None

    def snapshot(self) -> list[Proxy]:
        with self._lock:
            return list(self._items)

    def size(self) -> int:
        with self._lock:
            return len(self._items)

    def remaining(self) -> int:
        with self._lock:
            return sum(1 for p in self._items if p.key not in self._used)


# ---------------------------------------------------------------------------
# System proxy backends
# ---------------------------------------------------------------------------

class Backend:
    name = "base"
    supports_socks = False

    def apply(self, proxy: Proxy) -> None:
        raise NotImplementedError

    def clear(self) -> None:
        raise NotImplementedError


class NullBackend(Backend):
    name = "dry-run"

    def apply(self, proxy: Proxy) -> None:
        pass

    def clear(self) -> None:
        pass


class EnvBackend(Backend):
    """Only affects this process and its children (prints an export line)."""

    name = "env"
    supports_socks = True

    def apply(self, proxy: Proxy) -> None:
        scheme = "socks5h" if proxy.kind.startswith("socks") else "http"
        url = f"{scheme}://{proxy.host}:{proxy.port}"
        for key in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY",
                    "http_proxy", "https_proxy", "all_proxy"):
            os.environ[key] = url

    def clear(self) -> None:
        for key in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY",
                    "http_proxy", "https_proxy", "all_proxy"):
            os.environ.pop(key, None)


class GnomeBackend(Backend):
    name = "gnome"
    supports_socks = False

    def __init__(self) -> None:
        if shutil.which("gsettings") is None:
            raise RuntimeError("gsettings not found")
        subprocess.run(["gsettings", "get", "org.gnome.system.proxy", "mode"],
                       check=True, capture_output=True, timeout=5)

    @staticmethod
    def _set(schema: str, key: str, value: str) -> None:
        subprocess.run(["gsettings", "set", schema, key, value],
                       check=True, capture_output=True, timeout=5)

    def apply(self, proxy: Proxy) -> None:
        self._set("org.gnome.system.proxy", "mode", "manual")
        self._set("org.gnome.system.proxy", "use-same-proxy", "true")
        for scheme in ("http", "https", "ftp"):
            self._set(f"org.gnome.system.proxy.{scheme}", "host", proxy.host)
            self._set(f"org.gnome.system.proxy.{scheme}", "port", str(proxy.port))
        EnvBackend().apply(proxy)

    def clear(self) -> None:
        try:
            self._set("org.gnome.system.proxy", "mode", "none")
        finally:
            EnvBackend().clear()


class WindowsBackend(Backend):
    name = "windows"
    supports_socks = True

    def __init__(self) -> None:
        if not sys.platform.startswith("win"):
            raise RuntimeError("not running on Windows")
        import winreg  # noqa: F401  (import check only)

    @staticmethod
    def _refresh() -> None:
        try:
            import ctypes
            INTERNET_OPTION_SETTINGS_CHANGED = 39
            INTERNET_OPTION_REFRESH = 37
            ctypes.windll.wininet.InternetSetOptionW(0, INTERNET_OPTION_SETTINGS_CHANGED, 0, 0)
            ctypes.windll.wininet.InternetSetOptionW(0, INTERNET_OPTION_REFRESH, 0, 0)
        except Exception:
            pass

    def apply(self, proxy: Proxy) -> None:
        import winreg
        path = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
        value = (f"socks={proxy.host}:{proxy.port}"
                 if proxy.kind.startswith("socks") else f"{proxy.host}:{proxy.port}")
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 1)
            winreg.SetValueEx(key, "ProxyServer", 0, winreg.REG_SZ, value)
        self._refresh()

    def clear(self) -> None:
        import winreg
        path = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 0)
        self._refresh()


class MacBackend(Backend):
    name = "macos"
    supports_socks = False

    def __init__(self, service: str) -> None:
        if sys.platform != "darwin":
            raise RuntimeError("not running on macOS")
        if shutil.which("networksetup") is None:
            raise RuntimeError("networksetup not found")
        self.service = service

    def apply(self, proxy: Proxy) -> None:
        host, port = proxy.host, str(proxy.port)
        for flag in ("-setwebproxy", "-setsecurewebproxy"):
            subprocess.run(["networksetup", flag, self.service, host, port],
                           check=True, capture_output=True, timeout=10)
        for flag in ("-setwebproxystate", "-setsecurewebproxystate"):
            subprocess.run(["networksetup", flag, self.service, "on"],
                           check=True, capture_output=True, timeout=10)

    def clear(self) -> None:
        for flag in ("-setwebproxystate", "-setsecurewebproxystate"):
            subprocess.run(["networksetup", flag, self.service, "off"],
                           check=False, capture_output=True, timeout=10)


class AdbBackend(Backend):
    """Sets the global HTTP proxy of an Android device over adb."""

    name = "adb"
    supports_socks = False

    def __init__(self, serial: Optional[str]) -> None:
        if shutil.which("adb") is None:
            raise RuntimeError("adb not found in PATH")
        self.prefix = ["adb"] + (["-s", serial] if serial else [])

    def _shell(self, *args: str) -> None:
        subprocess.run(self.prefix + ["shell", *args],
                       check=True, capture_output=True, timeout=10)

    def apply(self, proxy: Proxy) -> None:
        self._shell("settings", "put", "global", "http_proxy",
                    f"{proxy.host}:{proxy.port}")
        self._shell("settings", "put", "global", "global_http_proxy_host", proxy.host)
        self._shell("settings", "put", "global", "global_http_proxy_port", str(proxy.port))

    def clear(self) -> None:
        self._shell("settings", "put", "global", "http_proxy", ":0")
        self._shell("settings", "delete", "global", "global_http_proxy_host")
        self._shell("settings", "delete", "global", "global_http_proxy_port")


def build_backend(name: str, args, log) -> Backend:
    def construct(kind: str) -> Backend:
        if kind == "dry-run":
            return NullBackend()
        if kind == "env":
            return EnvBackend()
        if kind == "gnome":
            return GnomeBackend()
        if kind == "windows":
            return WindowsBackend()
        if kind == "macos":
            return MacBackend(args.service)
        if kind == "adb":
            return AdbBackend(args.adb_serial)
        raise RuntimeError(f"unknown backend {kind}")

    if args.dry_run:
        log("[backend] dry-run - the system proxy will NOT be changed")
        return NullBackend()

    if name != "auto":
        backend = construct(name)
        log(f"[backend] {backend.name}")
        return backend

    order = ["windows", "macos", "gnome", "env"]
    for kind in order:
        try:
            backend = construct(kind)
            log(f"[backend] {backend.name}")
            return backend
        except Exception as exc:  # noqa: BLE001
            log(f"[backend] {kind} unavailable ({exc})")
    return EnvBackend()


# ---------------------------------------------------------------------------
# State files
# ---------------------------------------------------------------------------

class Store:
    def __init__(self, directory: Path) -> None:
        self.dir = directory
        self.dir.mkdir(parents=True, exist_ok=True)

    def save_alive(self, proxies: list[Proxy]) -> None:
        ordered = sorted(proxies, key=lambda p: p.latency_ms)
        (self.dir / "alive.txt").write_text(
            "".join(f"{p.host}:{p.port}\n" for p in ordered), encoding="utf-8")
        rows = ["host,port,scheme,latency_ms,egress_ip"]
        rows += [f"{p.host},{p.port},{p.kind},{p.latency_ms:.0f},{p.egress}"
                 for p in ordered]
        (self.dir / "alive.csv").write_text("\n".join(rows) + "\n", encoding="utf-8")

    def save_scraped(self, proxies: list[Proxy]) -> None:
        (self.dir / "scraped.txt").write_text(
            "".join(f"{p.host}:{p.port}\n" for p in proxies), encoding="utf-8")

    def save_current(self, proxy: Optional[Proxy]) -> None:
        text = "" if proxy is None else f"{proxy.kind}://{proxy.host}:{proxy.port}\n"
        (self.dir / "current.txt").write_text(text, encoding="utf-8")

    def append_rotation(self, proxy: Proxy) -> None:
        line = (f"{time.strftime('%Y-%m-%d %H:%M:%S')} "
                f"{proxy.kind}://{proxy.host}:{proxy.port} {proxy.latency_ms:.0f}ms\n")
        with (self.dir / "rotation.log").open("a", encoding="utf-8") as handle:
            handle.write(line)


# ---------------------------------------------------------------------------
# Engine: scrape + check + refill
# ---------------------------------------------------------------------------

class Engine:
    def __init__(self, args, log, check: tuple[str, int, str],
                 local_ip: str, backend: Backend) -> None:
        self.args = args
        self.log = log
        self.check = check
        self.local_ip = local_ip
        self.backend = backend
        self.pool = Pool()
        self.store = Store(Path(args.state_dir))
        self._checked: set[str] = set()
        self._checked_lock = threading.Lock()
        self._refill_lock = threading.Lock()
        self._refilling = threading.Event()
        self._last_refill = 0.0

    # -- scraping ---------------------------------------------------------
    def _sources(self) -> list[tuple[str, str]]:
        wanted = {p.strip() for p in self.args.protocols.split(",") if p.strip()}
        if self.args.sources:
            rows: list[tuple[str, str]] = []
            for line in Path(self.args.sources).read_text(encoding="utf-8").splitlines():
                line = line.split("#", 1)[0].strip()
                if not line:
                    continue
                parts = line.split()
                url = parts[0]
                kind = parts[1] if len(parts) > 1 else "http"
                rows.append((url, kind))
            sources = rows
        else:
            sources = default_sources()
        if wanted:
            sources = [s for s in sources if s[1] in wanted]
        return sources

    def scrape(self) -> list[Proxy]:
        sources = self._sources()
        self.log(f"[refill] downloading {len(sources)} source(s) ...")
        proxies = scrape(
            sources,
            workers=min(self.args.threads, max(4, len(sources))),
            timeout=self.args.timeout,
            per_source_cap=self.args.max_per_source,
            log=self.log,
        )
        self.store.save_scraped(proxies)
        self.log(f"[refill] {len(proxies)} unique candidate(s) after de-duplication")
        with self._checked_lock:
            fresh = [p for p in proxies if p.key not in self._checked]
        if len(fresh) > self.args.max_check:
            random.shuffle(fresh)
            fresh = fresh[: self.args.max_check]
        self.log(f"[refill] checking {len(fresh)} candidate(s) with {self.args.threads} threads")
        return fresh

    # -- checking ---------------------------------------------------------
    def check_many(self, candidates: list[Proxy]) -> list[Proxy]:
        alive: list[Proxy] = []
        if not candidates:
            return alive

        with self._checked_lock:
            for proxy in candidates:
                self._checked.add(proxy.key)

        done = 0
        total = len(candidates)
        started = time.monotonic()

        with ThreadPoolExecutor(max_workers=self.args.threads) as pool:
            futures = {
                pool.submit(check_proxy, proxy, self.check, self.args.timeout,
                            self.local_ip, self.args.require_egress_diff): proxy
                for proxy in candidates
            }
            for future in as_completed(futures):
                done += 1
                result = future.result()
                if result is not None:
                    alive.append(result)
                if done % max(25, total // 10) == 0 or done == total:
                    rate = done / max(time.monotonic() - started, 0.001)
                    self.log(f"[check] {done}/{total} ({rate:.0f}/s) - alive: {len(alive)}")

        alive.sort(key=lambda p: p.latency_ms)
        return alive

    # -- refilling --------------------------------------------------------
    def refill(self) -> int:
        with self._refill_lock:
            self._last_refill = time.monotonic()
            candidates = self.scrape()
            alive = self.check_many(candidates)
            added = self.pool.add(alive)
            if alive:
                self.store.save_alive(self.pool.snapshot())
            self.log(f"[refill] +{added} usable proxy(ies), pool={self.pool.size()}, "
                     f"remaining={self.pool.remaining()}")
            return added

    def trigger_refill(self) -> None:
        if self._refilling.is_set():
            return
        if time.monotonic() - self._last_refill < self.args.refill_cooldown:
            return

        def runner() -> None:
            self._refilling.set()
            try:
                self.refill()
            except Exception as exc:  # noqa: BLE001
                self.log(f"[refill] failed: {exc}")
            finally:
                self._refilling.clear()

        threading.Thread(target=runner, name="refill", daemon=True).start()

    def ensure_min(self) -> None:
        if self.pool.remaining() >= self.args.min_pool:
            return
        for attempt in range(1, self.args.attempts + 1):
            self.log(f"[startup] filling pool (attempt {attempt}/{self.args.attempts})")
            self.refill()
            if self.pool.remaining() >= self.args.min_pool:
                return
            time.sleep(min(3.0 * attempt, 10.0))
        self.log(f"[startup] only {self.pool.remaining()} usable proxy(ies) - continuing anyway")


# ---------------------------------------------------------------------------
# Rotation loop
# ---------------------------------------------------------------------------

def rotation_loop(engine: Engine, backend: Backend, args, stop: threading.Event) -> None:
    log = engine.log
    while not stop.is_set():
        if engine.pool.remaining() <= args.refill_at:
            engine.trigger_refill()

        proxy = engine.pool.take()
        if proxy is None:
            log("[rotate] pool is empty - refreshing now")
            if not engine._refilling.is_set():
                try:
                    engine.refill()
                except Exception as exc:  # noqa: BLE001
                    log(f"[rotate] refill failed: {exc}")
            stop.wait(2.0)
            continue

        try:
            backend.apply(proxy)
            engine.store.save_current(proxy)
            engine.store.append_rotation(proxy)
            log(f"[rotate] {proxy.label():<21} {proxy.kind:<6} "
                f"{proxy.latency_ms:6.0f} ms  left={engine.pool.remaining()}")
        except Exception as exc:  # noqa: BLE001
            log(f"[rotate] could not apply {proxy.label()}: {exc}")

        stop.wait(args.interval)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args(argv: Optional[list[str]] = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Scrape, check and rotate public proxies; sets the system proxy every N seconds.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--interval", type=float, default=3.0,
                        help="seconds between proxy switches")
    parser.add_argument("--timeout", type=float, default=6.0,
                        help="per-connection timeout in seconds")
    parser.add_argument("--threads", type=int, default=400,
                        help="parallel workers for scraping/checking")
    parser.add_argument("--protocols", default="http,https",
                        help="comma separated proxy types to scrape (http,https,socks4,socks5)")
    parser.add_argument("--check-url", default=None,
                        help="HTTP URL that echoes the client IP")
    parser.add_argument("--sources", default=None,
                        help="optional file with 'url [protocol]' per line")
    parser.add_argument("--state-dir", default=".",
                        help="directory for alive.txt / current.txt / rotation.log")
    parser.add_argument("--min-pool", type=int, default=5,
                        help="try to keep at least this many usable proxies")
    parser.add_argument("--refill-at", type=int, default=15,
                        help="re-scrape when at most this many proxies are unused")
    parser.add_argument("--refill-cooldown", type=float, default=15.0,
                        help="minimum seconds between two automatic re-scrapes")
    parser.add_argument("--attempts", type=int, default=4,
                        help="refill attempts at startup")
    parser.add_argument("--max-check", type=int, default=2000,
                        help="max candidates checked per refill")
    parser.add_argument("--max-per-source", type=int, default=5000,
                        help="max proxies taken from a single source")
    parser.add_argument("--require-egress-diff", action="store_true", default=True,
                        help="drop proxies that return your own IP")
    parser.add_argument("--allow-same-ip", dest="require_egress_diff",
                        action="store_false", help="keep transparent proxies")
    parser.add_argument("--backend", default="auto",
                        choices=["auto", "gnome", "windows", "macos", "adb", "env", "dry-run"],
                        help="where to apply the system proxy")
    parser.add_argument("--service", default="Wi-Fi",
                        help="macOS network service name")
    parser.add_argument("--adb-serial", default=None,
                        help="adb device serial (Android)")
    parser.add_argument("--dry-run", action="store_true",
                        help="never touch system settings")
    parser.add_argument("--no-restore", action="store_true",
                        help="keep the last proxy set after exit")
    parser.add_argument("--once", action="store_true",
                        help="scrape+check once, write files and exit")
    parser.add_argument("--top", type=int, default=20,
                        help="how many proxies to print in --once mode")
    parser.add_argument("--list-sources", action="store_true",
                        help="print the built-in source list and exit")
    parser.add_argument("--version", action="version", version=f"proxy-rotator {__version__}")
    parser.add_argument("--quiet", action="store_true", help="less output")
    return parser.parse_args(argv)


def main(argv: Optional[list[str]] = None) -> int:
    args = parse_args(argv)
    log = make_logger(args.quiet)

    if args.list_sources:
        for url, kind in default_sources():
            print(f"{url}\t{kind}")
        return 0

    if args.interval <= 0:
        log("error: --interval must be > 0")
        return 2
    if args.threads < 1:
        log("error: --threads must be >= 1")
        return 2

    check, local_ip = pick_check_target(log, args.check_url, args.timeout)
    log(f"[check] your public IP: {local_ip}")

    backend = build_backend(args.backend, args, log)
    if args.dry_run:
        backend = NullBackend()

    engine = Engine(args, log, check, local_ip, backend)

    stop = threading.Event()
    restored = threading.Event()

    def restore() -> None:
        if restored.is_set() or args.no_restore:
            return
        restored.set()
        try:
            backend.clear()
            engine.store.save_current(None)
            log("[exit] system proxy cleared")
        except Exception as exc:  # noqa: BLE001
            log(f"[exit] could not clear the proxy: {exc}")

    atexit.register(restore)

    def handle_signal(signum, _frame):
        log(f"[exit] signal {signum} - stopping")
        stop.set()

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            signal.signal(sig, handle_signal)
        except (ValueError, OSError):
            pass

    try:
        if args.once:
            engine.refill()
            alive = engine.pool.snapshot()
            log(f"[done] {len(alive)} usable proxy(ies)")
            for proxy in alive[: max(0, args.top)]:
                print(f"{proxy.host}:{proxy.port:<6} {proxy.kind:<6} "
                      f"{proxy.latency_ms:7.1f} ms  egress={proxy.egress}")
            return 0

        engine.ensure_min()
        if engine.pool.size() == 0:
            log("no usable proxy found - try again later or raise --max-check")
            return 1

        log(f"[start] rotating every {args.interval:g}s | pool={engine.pool.size()} "
            f"| refill_at={args.refill_at}")
        rotation_loop(engine, backend, args, stop)
        return 0
    finally:
        restore()
        atexit.unregister(restore)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
